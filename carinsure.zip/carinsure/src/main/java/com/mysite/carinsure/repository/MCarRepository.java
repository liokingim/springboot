package com.mysite.carinsure.repository;

import java.util.Optional;

import org.springframework.data.repository.Repository;

import com.mysite.carinsure.entity.MCar;

public interface MCarRepository extends Repository<MCar, Long> {

    MCar save(MCar entity);

    Optional<MCar> findById(Long id);
}