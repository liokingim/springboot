package com.mysite.carinsure.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.mysite.carinsure.dto.CarInspectionDashboardDto;

public interface CarDashboardService {
	List<CarInspectionDashboardDto> getInspectionDashboardForCsv();

    List<CarInspectionDashboardDto> getInspectionDashboard(String carName);

    Page<CarInspectionDashboardDto> getInspectionDashboard(String carName, Pageable pageable);
}