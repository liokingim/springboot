package com.mysite.carinsure.util;

import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.stereotype.Component;

import com.mysite.carinsure.dto.CarInspectionDashboardDto;

@Component
public class CarDashboardCsvWriter {

    private static final String NEW_LINE = "\r\n";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public byte[] write(List<CarInspectionDashboardDto> list) {
        StringBuilder sb = new StringBuilder();

        sb.append('\uFEFF');
        sb.append("차량번호,차량명,신차 날짜,중요부검사 날짜,일반검사 날짜,월검사 날짜")
          .append(NEW_LINE);

        for (CarInspectionDashboardDto item : list) {
            sb.append(escape(item.getCarNo())).append(",");
            sb.append(escape(item.getCarName())).append(",");
            sb.append(formatDate(item.getNewCarDate())).append(",");
            sb.append(formatDate(item.getImportantInspectDate())).append(",");
            sb.append(formatDate(item.getNormalInspectDate())).append(",");
            sb.append(formatDate(item.getMonthlyInspectDate())).append(NEW_LINE);
        }

        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }

    private String formatDate(String date) {
        return date == null ? "" : date.formatted(DATE_FORMATTER);
    }

    private String escape(String value) {
        if (value == null) {
            return "";
        }
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }
}