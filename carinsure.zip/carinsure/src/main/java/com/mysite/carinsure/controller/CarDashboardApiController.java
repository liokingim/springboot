package com.mysite.carinsure.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mysite.carinsure.dto.CarInspectionDashboardDto;
import com.mysite.carinsure.service.CarDashboardService;

@RestController
public class CarDashboardApiController {

    private final CarDashboardService carDashboardService;

    public CarDashboardApiController(CarDashboardService carDashboardService) {
        this.carDashboardService = carDashboardService;
    }

    @GetMapping("/api/car/inspect")
    public Page<CarInspectionDashboardDto> getInspectionDashboard(
            @RequestParam(name = "carName", required = false) String carName,
            Pageable pageable
    ) {
        return carDashboardService.getInspectionDashboard(carName, pageable);
    }
}