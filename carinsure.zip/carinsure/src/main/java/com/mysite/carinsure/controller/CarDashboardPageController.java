package com.mysite.carinsure.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysite.carinsure.dto.CarInspectionDashboardDto;
import com.mysite.carinsure.service.CarDashboardService;

@Controller
public class CarDashboardPageController {

    private final CarDashboardService carDashboardService;

    public CarDashboardPageController(CarDashboardService carDashboardService) {
        this.carDashboardService = carDashboardService;
    }

    @GetMapping("/dashboard")
    public String dashboard(
            @RequestParam(name = "carName", required = false) String carName,
            Pageable pageable,
            Model model
    ) {
        Page<CarInspectionDashboardDto> pageData =
                carDashboardService.getInspectionDashboard(carName, pageable);

        model.addAttribute("pageData", pageData);
        model.addAttribute("list", pageData.getContent());
        model.addAttribute("carName", carName);

        return "dashboard";
    }
}