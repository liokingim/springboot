package com.mysite.carinsure.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.mysite.carinsure.dto.CarInspectionDashboardDto;
import com.mysite.carinsure.repository.CarDashboardQueryRepository;
import com.mysite.carinsure.repository.projection.CarInspectionDashboardProjection;

@Service
public class CarDashboardServiceImpl implements CarDashboardService {

    private final CarDashboardQueryRepository carDashboardQueryRepository;

    public CarDashboardServiceImpl(CarDashboardQueryRepository carDashboardQueryRepository) {
        this.carDashboardQueryRepository = carDashboardQueryRepository;
    }

    @Override
    public List<CarInspectionDashboardDto> getInspectionDashboardForCsv() {
        return carDashboardQueryRepository.findInspectionDashboard(null, Pageable.unpaged())
                .getContent()
                .stream()
                .map(this::toDto)
                .toList();
    }

    @Override
    public List<CarInspectionDashboardDto> getInspectionDashboard(String carName) {
        String searchCarName = normalizeKeyword(carName);

        return carDashboardQueryRepository.findInspectionDashboard(searchCarName, Pageable.unpaged())
                .getContent()
                .stream()
                .map(this::toDto)
                .toList();
    }

    @Override
    public Page<CarInspectionDashboardDto> getInspectionDashboard(String carName, Pageable pageable) {
        String searchCarName = normalizeKeyword(carName);

        return carDashboardQueryRepository.findInspectionDashboard(searchCarName, pageable)
                .map(this::toDto);
    }

    private String normalizeKeyword(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return null;
        }
        return keyword.trim();
    }

    private CarInspectionDashboardDto toDto(CarInspectionDashboardProjection p) {
        return new CarInspectionDashboardDto(
                p.getCarNo(),
                p.getCarName(),
                p.getNewCarDate(),
                p.getImportantInspectDate(),
                p.getNormalInspectDate(),
                p.getMonthlyInspectDate()
        );
    }
}
