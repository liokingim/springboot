package com.mysite.carinsure.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "m_insure")
@Getter
@Setter
public class MInsure {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long seq;

    @Column(name = "carNo", nullable = false, length = 20)
    private String carNo;

    @Column(name = "type", length = 50)
    private String type;

    @Column(name = "classname", length = 2)
    private String classname;

    @Column(name = "parts", length = 100)
    private String parts;
    
    @Column(name = "insuredate")
    private String insuredate;

    @Column(name = "created", nullable = false)
    private String created;

    @Column(name = "updated", nullable = false)
    private String updated;

    @Column(name = "version", nullable = false)
    private Integer version;

    @Column(name = "deleteflg", nullable = false)
    private Integer deleteflg;
}