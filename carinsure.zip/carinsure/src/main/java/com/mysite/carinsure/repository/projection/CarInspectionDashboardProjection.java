package com.mysite.carinsure.repository.projection;

public interface CarInspectionDashboardProjection {
    String getCarNo();

    String getCarName();

    String getNewCarDate();

    String getImportantInspectDate();

    String getNormalInspectDate();

    String getMonthlyInspectDate();
}
