package com.mysite.carinsure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarinsureApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarinsureApplication.class, args);
	}

}
