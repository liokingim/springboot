package com.mysite.carinsure.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "m_car")
@Getter
@Setter
public class MCar {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long seq;

    @Column(name = "carNo", nullable = false, unique = true, length = 20)
    private String carNo;

    @Column(name = "carName", nullable = false, length = 100)
    private String carName;

    @Column(name = "created", nullable = false)
    private String created;

    @Column(name = "updated", nullable = false)
    private String updated;

    @Column(name = "version", nullable = false)
    private Integer version;

    @Column(name = "deleteflg", nullable = false)
    private Integer deleteflg;
}