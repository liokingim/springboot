package com.mysite.carinsure.controller;

import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mysite.carinsure.dto.CarInspectionDashboardDto;
import com.mysite.carinsure.service.CarDashboardService;
import com.mysite.carinsure.util.CarDashboardCsvWriter;

@RestController
public class CarDashboardCsvController {

    private final CarDashboardService carDashboardService;
    private final CarDashboardCsvWriter carDashboardCsvWriter;

    public CarDashboardCsvController(
            CarDashboardService carDashboardService,
            CarDashboardCsvWriter carDashboardCsvWriter
    ) {
        this.carDashboardService = carDashboardService;
        this.carDashboardCsvWriter = carDashboardCsvWriter;
    }

    @GetMapping(value = "/api/car/inspect/csv", produces = "text/csv")
    public ResponseEntity<byte[]> downloadCsv() {
    	List<CarInspectionDashboardDto> list = carDashboardService.getInspectionDashboardForCsv();
        byte[] csvBytes = carDashboardCsvWriter.write(list);

        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"car-inspection-dashboard.csv\"")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(csvBytes);
    }
}