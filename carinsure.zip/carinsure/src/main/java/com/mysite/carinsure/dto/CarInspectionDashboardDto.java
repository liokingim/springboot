package com.mysite.carinsure.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CarInspectionDashboardDto {

    public CarInspectionDashboardDto(String carNo, String carName, String newCarDate, String importantInspectDate,
			String normalInspectDate, String monthlyInspectDate) {
		super();
		this.carNo = carNo;
		this.carName = carName;
		this.newCarDate = newCarDate;
		this.importantInspectDate = importantInspectDate;
		this.normalInspectDate = normalInspectDate;
		this.monthlyInspectDate = monthlyInspectDate;
	}
    
	private String carNo;
    private String carName;
    private String newCarDate;
    private String importantInspectDate;
    private String normalInspectDate;
    private String monthlyInspectDate;
}
