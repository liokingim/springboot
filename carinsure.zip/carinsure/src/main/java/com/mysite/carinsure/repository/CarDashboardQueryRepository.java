package com.mysite.carinsure.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.mysite.carinsure.entity.MCar;
import com.mysite.carinsure.repository.projection.CarInspectionDashboardProjection;

public interface CarDashboardQueryRepository extends Repository<MCar, Long> {

    @Query(
            value = """
                SELECT
                    c.carNo AS carNo,
                    c.carName AS carName,

                    agg.new_car_date AS newCarDate,

                    COALESCE(
                        agg.imp_f_date,
                        agg.imp_a_date,
                        agg.imp_b_date,
                        agg.new_car_date
                    ) AS importantInspectDate,

                    COALESCE(
                        agg.gen_f_date,
                        agg.gen_a_date,
                        agg.gen_b_date,
                        agg.new_car_date
                    ) AS normalInspectDate,

                    COALESCE(
                        agg.mon_f_date,
                        agg.mon_a_date,
                        agg.mon_b_date,
                        agg.new_car_date
                    ) AS monthlyInspectDate

                FROM m_car c
                LEFT JOIN (
                    SELECT
                        i.carNo,

                        MAX(CASE WHEN i.`classname` = '01' THEN i.insuredate END) AS new_car_date,
                        MAX(CASE WHEN i.`classname` = '02' AND i.parts = 'F' THEN i.insuredate END) AS imp_f_date,
                        MAX(CASE WHEN i.`classname` = '02' AND i.parts = 'A' THEN i.insuredate END) AS imp_a_date,
                        MAX(CASE WHEN i.`classname` = '02' AND i.parts = 'B' THEN i.insuredate END) AS imp_b_date,
                        MAX(CASE WHEN i.`classname` = '03' AND i.parts = 'F' THEN i.insuredate END) AS gen_f_date,
                        MAX(CASE WHEN i.`classname` = '03' AND i.parts = 'A' THEN i.insuredate END) AS gen_a_date,
                        MAX(CASE WHEN i.`classname` = '03' AND i.parts = 'B' THEN i.insuredate END) AS gen_b_date,
                        MAX(CASE WHEN i.`classname` = '04' AND i.parts = 'F' THEN i.insuredate END) AS mon_f_date,
                        MAX(CASE WHEN i.`classname` = '04' AND i.parts = 'A' THEN i.insuredate END) AS mon_a_date,
                        MAX(CASE WHEN i.`classname` = '04' AND i.parts = 'B' THEN i.insuredate END) AS mon_b_date
                    FROM m_insure i
                    WHERE i.deleteflg = 0
                    GROUP BY i.carNo
                ) agg
                    ON c.carNo = agg.carNo
                WHERE c.deleteflg = 0
                  AND (
                        :carName IS NULL
                        OR c.carName LIKE CONCAT('%', :carName, '%')
                      )
                ORDER BY c.carNo
                """,
            countQuery = """
                SELECT COUNT(*)
                FROM m_car c
                WHERE c.deleteflg = 0
                  AND (
                        :carName IS NULL
                        OR c.carName LIKE CONCAT('%', :carName, '%')
                      )
                """,
            nativeQuery = true
        )
        Page<CarInspectionDashboardProjection> findInspectionDashboard(
                @Param("carName") String carName,
                Pageable pageable
        );
}
