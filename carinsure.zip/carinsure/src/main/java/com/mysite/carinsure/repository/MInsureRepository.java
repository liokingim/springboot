package com.mysite.carinsure.repository;

import java.util.Optional;

import org.springframework.data.repository.Repository;

import com.mysite.carinsure.entity.MInsure;

public interface MInsureRepository extends Repository<MInsure, Long> {

    MInsure save(MInsure entity);

    Optional<MInsure> findById(Long id);
}
