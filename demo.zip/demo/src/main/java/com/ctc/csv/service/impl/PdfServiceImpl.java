package com.ctc.csv.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.*;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.ctc.csv.PdfFontLoader;
import com.ctc.csv.service.PdfService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.font.PDType0Font;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.lang.reflect.Field;
import java.nio.file.*;
import java.util.*;

@Service
public class PdfServiceImpl implements PdfService {

    private static final Logger logger = LoggerFactory.getLogger(PdfServiceImpl.class);

    private final PdfFontLoader pdfFontLoader;
    
    @Value("${app.template.pdf.path}")
    private String TEMPLATE_PDF_PATH;

    @Value("${app.template.pdf.coords}")
    private String TEMPLATE_PDF_COORDS_PATH;

    @Value("${app.template.pdf.output-path}")
    private String PDF_OUTPUT_DIR;

    private static final String TEMPLATE_PDF_FILENAME = "template2.pdf";
    private static final String TEMPLATE_PDF_COORDS_JSON_FILENAME = "template2.json";

    public PdfServiceImpl(PdfFontLoader pdfFontLoader) {
        this.pdfFontLoader = pdfFontLoader;
    }

    @Override
    public String createPdf(Object record, String outputName) throws Exception {
        if (record == null) {
            throw new IllegalArgumentException("PDF에 기록할 데이터 객체가 없습니다.");
        }

        // ① 좌표 JSON 로드
        ObjectMapper objectMapper = new ObjectMapper();
        InputStream coordStream = new ClassPathResource(
                TEMPLATE_PDF_COORDS_PATH + TEMPLATE_PDF_COORDS_JSON_FILENAME).getInputStream();
        Map<String, Object> coords = objectMapper.readValue(coordStream, Map.class);

        // ② 출력 디렉토리 생성
        Path outputDir = Paths.get(PDF_OUTPUT_DIR);
        if (!Files.exists(outputDir)) Files.createDirectories(outputDir);

        String fileName = (outputName != null && !outputName.isBlank())
                ? outputName
                : record.getClass().getSimpleName() + "_" + System.currentTimeMillis() + ".pdf";

        File outputPdfFile = new File(outputDir.toFile(), fileName);
        File templateFile = new ClassPathResource(TEMPLATE_PDF_PATH + TEMPLATE_PDF_FILENAME).getFile();

        // ③ PDF 작성
        try (PDDocument document = PDDocument.load(templateFile)) {
            PDPage page = document.getPage(0);
            PDPageContentStream cs = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true);

            // ④ 폰트 로드
            Resource fontResource = pdfFontLoader.getFontResource();
            PDType0Font font;
            try (InputStream fontStream = fontResource.getInputStream()) {
                font = PDType0Font.load(document, fontStream);
            }

            // ⑤ 리플렉션으로 필드 순회
            for (Field field : record.getClass().getDeclaredFields()) {
                field.setAccessible(true);
                Object val = field.get(record);
                if (val == null) continue;

                String fieldName = field.getName();
                if (val instanceof String s) {
                    writeText(cs, font, coords, fieldName, s);
                } else if (val instanceof String[] arr) {
                    writeArray(cs, font, coords, fieldName, arr);
                }
            }

            cs.close();
            document.save(outputPdfFile);
        }

        logger.info("PDF 생성 완료: {}", outputPdfFile.getAbsolutePath());
        return outputPdfFile.getAbsolutePath();
    }

    /** 단일 텍스트 출력 */
    private void writeText(PDPageContentStream cs, PDType0Font font,
                           Map<String, Object> coords, String key, String value) throws IOException {
        if (value == null || value.isBlank() || !coords.containsKey(key)) return;
        Map<String, Object> pos = (Map<String, Object>) coords.get(key);
        float x = ((Number) pos.get("x")).floatValue();
        float y = ((Number) pos.get("y")).floatValue();
        float size = ((Number) pos.get("fontSize")).floatValue();

        cs.beginText();
        cs.setFont(font, size);
        cs.newLineAtOffset(x, y);
        cs.showText(value);
        cs.endText();
    }

    /** 배열 필드 출력 */
    private void writeArray(PDPageContentStream cs, PDType0Font font,
                            Map<String, Object> coords, String key, String[] values) throws IOException {
        if (!coords.containsKey(key)) return;
        List<Map<String, Object>> list = (List<Map<String, Object>>) coords.get(key);
        for (int i = 0; i < values.length && i < list.size(); i++) {
            String val = values[i];
            if (val == null || val.isBlank()) continue;

            Map<String, Object> pos = list.get(i);
            float x = ((Number) pos.get("x")).floatValue();
            float y = ((Number) pos.get("y")).floatValue();
            float size = ((Number) pos.get("fontSize")).floatValue();

            cs.beginText();
            cs.setFont(font, size);
            cs.newLineAtOffset(x, y);
            cs.showText(val);
            cs.endText();
        }
    }
}
