package com.ctc.csv.service;

public interface PdfService {

    String createPdf(Object record, String outputName) throws Exception;
}
