package com.ctc.csv.service;

import org.springframework.web.multipart.MultipartFile;

import com.ctc.csv.ReportRecord2;

import java.io.IOException;
import java.util.List;

public interface CsvService {

    /**
     * CSV 파일을 읽어서 Map 리스트로 변환
     * - 중복 헤더(예: 記事, 記事, 記事) 처리
     * - 따옴표 포함 필드("行事一覧")도 안전하게 파싱
     *
     * @param csvFile 업로드된 CSV 파일
     * @return CSV 한 행을 Map 형태로 담은 리스트
     */
    List<ReportRecord2> parseCsvWithDuplicateHeaders(MultipartFile csvFile) throws IOException;
}
