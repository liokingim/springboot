package com.ctc.csv;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

@Service
public class PdfFontLoader {

    private final ResourceLoader resourceLoader;

    // ResourceLoader 주입
    public PdfFontLoader(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    // 폰트 리소스를 가져오는 헬퍼 메서드
    public Resource getFontResource() {
        // classpath 경로로 접근합니다.
        return resourceLoader.getResource("classpath:static/font/ipag.ttf");
    }
}