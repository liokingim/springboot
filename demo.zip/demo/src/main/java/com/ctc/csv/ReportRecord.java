package com.ctc.csv;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ReportRecord {
    
    @JsonProperty("日付")
    public String date;

    @JsonProperty("天候")
    public String weather;

    @JsonProperty("気温")
    public String temperature;

    @JsonProperty("施工箇所")
    public String team;
    
    @JsonProperty("行事一覧")
    public String[] event;
    
    @JsonProperty("区分")
    public String section;
    
    @JsonProperty("車号")
    public String[] carNo;
    
    @JsonProperty("記事")
    public String memo;

    public void setCarNo(String value) {
        if (value != null && !value.isBlank()) {
            this.carNo = Arrays.stream(value.split("\\s*,\\s*"))
                    .map(String::trim)
                    .toArray(String[]::new);
        } else {
            this.carNo = new String[0];
        }
    }
    
    public void setEvent(String value) {
        if (value != null && !value.isBlank()) {
            this.event = Arrays.stream(value.split("\\s*,\\s*"))
                    .map(String::trim)
                    .toArray(String[]::new);
        } else {
            this.event = new String[0];
        }
    }
    
}
