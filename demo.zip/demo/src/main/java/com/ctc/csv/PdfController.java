package com.ctc.csv;

import java.io.*;
import java.nio.file.*;
import java.util.*;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import org.springframework.http.MediaType;


@Controller
@RequestMapping("/pdf")
public class PdfController {
    
    private static final Logger logger = LoggerFactory.getLogger(PdfController.class);

    private final PdfFontLoader pdfFontLoader;
    
    @Value("${app.template.pdf.path}")
    private String TEMPLATE_PDF_PATH;

    @Value("${app.template.pdf.coords}")
    private String TEMPLATE_PDF_COORDS_PATH;
    
    @Value("${app.template.pdf.output-path}")
    private String PDF_OUTPUT_DIR;
    
    private String TEMPLATE_PDF_FILENAME = "template.pdf";
    
    private String TEMPLATE_PDF_COORDS_JSON_FILENAME = "template.json";
    
    public PdfController(PdfFontLoader pdfFontLoader) {
        this.pdfFontLoader = pdfFontLoader;
    }
    
    @GetMapping(value = "/upload")
    public String index() {
        logger.info("Accessing upload page");
        return "upload"; // upload.html
    }

    @PostMapping(value = "/upload-csv", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    public String uploadCsv(@RequestParam("csvFile") MultipartFile csvFile, Model model) 
            throws Exception {
       
        logger.info("Starting.......... CSV file: {}", csvFile.getOriginalFilename());
        
        if (csvFile.isEmpty()) {
            throw new IllegalArgumentException("CSV 파일이 비어 있습니다.");
        }

        // CSV 임시 저장
        Path tempDir = Files.createTempDirectory("csvupload");
        Path csvPath = tempDir.resolve(Objects.requireNonNull(csvFile.getOriginalFilename()));
        Files.copy(csvFile.getInputStream(), csvPath, StandardCopyOption.REPLACE_EXISTING);

        List<ReportRecord> records = new ArrayList<>();
        
        try (InputStream inputStream = csvFile.getInputStream()) {
            
            logger.info("CsvMapper-----");
            
            CsvMapper mapper = new CsvMapper();
            CsvSchema schema = CsvSchema.emptySchema().withHeader();

            MappingIterator<ReportRecord> it = mapper.readerFor(ReportRecord.class)
                                                     .with(schema)
                                                     .readValues(inputStream);

            while (it.hasNext()) {
                records.add(it.next());
            }
        }
        

        // csv 내용을 출력
        System.out.println("=== CSV 매핑 결과 ===");
        records.forEach(System.out::println);

        // ② 좌표 JSON 로드
        ObjectMapper objectMapper = new ObjectMapper();
        InputStream coordStream = new ClassPathResource(TEMPLATE_PDF_COORDS_PATH + TEMPLATE_PDF_COORDS_JSON_FILENAME).getInputStream();
        Map<String, Object> coords = objectMapper.readValue(coordStream, Map.class);
        
        System.out.println("=== Loaded JSON Coordinates (raw Map) ===");
        System.out.println(coords);
        

        // 저장 폴더 생성
        Path outputDir = Paths.get(PDF_OUTPUT_DIR);
        if (!Files.exists(outputDir)) {
            Files.createDirectories(outputDir);
        }
        
        // 
        File outputPdffile = new File(PDF_OUTPUT_DIR, "report_" + System.currentTimeMillis() + ".pdf");
        
        // ③ PDF 템플릿 열기
        File templateFile = new ClassPathResource(TEMPLATE_PDF_PATH + TEMPLATE_PDF_FILENAME).getFile();
        
        // PDF 생성
        try (PDDocument document = PDDocument.load(templateFile)) {
            PDPage page = document.getPage(0);
            PDPageContentStream cs = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true);
            
            
            // 서비스로부터 미리 로드된 폰트 리소스를 가져옵니다.
            Resource fontResource = pdfFontLoader.getFontResource();

            // 2. 폰트 로드: fontResource -> InputStream -> PDType0Font
            PDType0Font font;
            try (InputStream fontStream = fontResource.getInputStream()) {
                // PDDocument 객체를 사용하여 폰트를 로드해야 합니다.
                font = PDType0Font.load(document, fontStream);
            }
            
            ReportRecord rec = records.get(0); // 첫 행 처리 예시

            System.out.println("=== pdf create ===");
            System.out.println(rec.date);
            
            
            // 단일 필드 출력
            writeText(cs, font, coords, "date", rec.date);
            writeText(cs, font, coords, "weather", rec.weather);
            writeText(cs, font, coords, "temperature", rec.temperature);
            writeText(cs, font, coords, "team", rec.team);
            writeText(cs, font, coords, "section", rec.section);
            writeText(cs, font, coords, "memo", rec.getMemo());
            
            // 배열 필드 출력
            writeArray(cs, font, coords, "event", rec.getEvent());
            writeArray(cs, font, coords, "carNo", rec.getCarNo());

            cs.close();
            document.save(outputPdffile);
            
            System.out.println("PDF 저장 완료: " + outputPdffile.getAbsolutePath());
        }
        return "result";
    }

    /**
     * 단일 필드 출력
     */
    private void writeText(PDPageContentStream cs, PDType0Font font, Map<String, Object> coords, String key, String value) throws IOException {
        if (value == null || value.isBlank()) return;
        if (!coords.containsKey(key)) return;
        Map<String, Object> pos = (Map<String, Object>) coords.get(key);
        float x = ((Number) pos.get("x")).floatValue();
        float y = ((Number) pos.get("y")).floatValue();
        float size = ((Number) pos.get("fontSize")).floatValue();

        cs.beginText();
        cs.setFont(font, size);
        cs.newLineAtOffset(x, y);
        cs.showText(value);
        cs.endText();
    }

    /**
     * 배열 필드 출력 (event, carNo 등)
     */
    private void writeArray(PDPageContentStream cs, PDType0Font font, Map<String, Object> coords, String key, String[] values) throws IOException {
        if (!coords.containsKey(key)) return;
        List<Map<String, Object>> list = (List<Map<String, Object>>) coords.get(key);
        for (int i = 0; i < values.length && i < list.size(); i++) {
            Map<String, Object> pos = list.get(i);
            float x = ((Number) pos.get("x")).floatValue();
            float y = ((Number) pos.get("y")).floatValue();
            float size = ((Number) pos.get("fontSize")).floatValue();
            String val = values[i];
            if (val == null || val.isBlank()) continue;

            cs.beginText();
            cs.setFont(font, size);
            cs.newLineAtOffset(x, y);
            cs.showText(val);
            cs.endText();
        }
    }
}
