package com.ctc.csv;

import java.io.*;
import java.nio.file.*;
import java.util.*;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

@Controller
@RequestMapping("/pdf")
public class PdfController {
    private static final Logger logger = LoggerFactory.getLogger(PdfController.class);

    @Value("${app.template.pdf.path}")
    private String TEMPLATE_PATH;

    @Value("${app.template.pdf.output-path}")
    private String OUTPUT_DIR;

    @GetMapping("/upload")
    public String index() {
        logger.info("Accessing upload page");
        return "upload"; // upload.html
    }

    @PostMapping("/upload-csv")
    public String uploadCsv(@RequestParam("csvFile") MultipartFile csvFile, Model model) 
            throws IOException, CsvException {
        logger.info("Starting CSV upload and PDF processing. CSV file: {}", csvFile.getOriginalFilename());
        
        if (csvFile.isEmpty()) {
            model.addAttribute("message", "CSV 파일을 선택해주세요.");
            return "upload";
        }

        // CSV 임시 저장
        Path tempDir = Files.createTempDirectory("csvupload");
        Path csvPath = tempDir.resolve(Objects.requireNonNull(csvFile.getOriginalFilename()));
        Files.copy(csvFile.getInputStream(), csvPath, StandardCopyOption.REPLACE_EXISTING);

        // CSV 데이터 읽기
        List<String[]> rows;
        try (CSVReader reader = new CSVReader(new FileReader(csvPath.toFile()))) {
            rows = reader.readAll();
        }

        if (rows.isEmpty()) {
            model.addAttribute("message", "CSV에 데이터가 없습니다.");
            return "upload";
        }

        // 헤더 제거
        if (rows.size() > 0 && rows.get(0)[0].equalsIgnoreCase("name")) {
            rows.remove(0);
        }

        // 저장 폴더 생성
        Path outputDir = Paths.get(OUTPUT_DIR);
        if (!Files.exists(outputDir)) {
            Files.createDirectories(outputDir);
        }


        // csv 내용을 출력
    	for (String[] row : rows) {
    		System.out.println(Arrays.toString(row));
    		
    		for (String value : row) {
    		    System.out.println(value);
    		}
    	}
        
        // PDF 생성
//        List<String> pdfUrls = new ArrayList<>();
//        int count = 1;
//        for (String[] row : rows) {
//            String filename = "form_" + System.currentTimeMillis() + "_" + count + ".pdf";
//            Path outputPath = outputDir.resolve(filename);
//            fillPdfForm(TEMPLATE_PATH, row, outputPath.toString());
//            pdfUrls.add("/pdfs/" + filename);
//            count++;
//        }
//
//        model.addAttribute("pdfUrls", pdfUrls);
//        model.addAttribute("message", "총 " + (count - 1) + "개의 PDF가 생성되었습니다!");
        return "result";
    }

    private void fillPdfForm(String templatePath, String[] rowData, String outputPath) throws IOException {
        try (PDDocument pdfDoc = PDDocument.load(new File(templatePath))) {
//            PDAcroForm form = pdfDoc.getDocumentCatalog().getAcroForm();
//            if (form == null) {
//                throw new IOException("템플릿 PDF에 AcroForm이 없습니다.");
//            }
//
//            setField(form, "name", getValue(rowData, 0));
//            setField(form, "age", getValue(rowData, 1));
//            setField(form, "address", getValue(rowData, 2));
//
//            form.flatten();
        	
        	
            pdfDoc.save(outputPath);
        }
    }

    private void setField(PDAcroForm form, String name, String value) throws IOException {
        PDField field = form.getField(name);
        if (field != null && value != null) {
            field.setValue(value);
        }
    }

    private String getValue(String[] arr, int index) {
        return index < arr.length ? arr[index] : "";
    }
}
