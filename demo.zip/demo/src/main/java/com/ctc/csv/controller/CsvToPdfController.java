package com.ctc.csv.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ctc.csv.ReportRecord2;
import com.ctc.csv.service.CsvService;
import com.ctc.csv.service.PdfService;
import com.example.pdf.validation.CsvValidator;

import java.util.List;

@Controller
@RequestMapping("/csv-to-pdf")
public class CsvToPdfController {

    private static final Logger logger = LoggerFactory.getLogger(CsvToPdfController.class);

    
    private final CsvService csvService;
    private final PdfService pdfService;
    
    @Autowired
    private CsvValidator csvValidator;

    public CsvToPdfController(CsvService csvService, PdfService pdfService) {
        this.csvService = csvService;
        this.pdfService = pdfService;
    }

    /** CSV 업로드 페이지 */
    @GetMapping("/upload")
    public String uploadPage() {
        logger.info("Accessing upload page");
        return "uploadcsv"; // upload.html (CSV 업로드 폼)
    }
    
   
    /** CSV 업로드 → PDF 생성 */
    @PostMapping(value = "/upload", consumes = {"multipart/form-data"})
    public String handleCsvUpload(@RequestParam("csvFile") MultipartFile csvFile, Model model) {
        logger.info("Accessing handleCsvUpload...");
        
        try {
            logger.info("... parseCsvWithDuplicateHeaders...");
            // ① CSV 파일 파싱 (중복 헤더 포함)
            List<ReportRecord2> records = csvService.parseCsvWithDuplicateHeaders(csvFile);
            if (records.isEmpty()) {
                model.addAttribute("message", "CSV 데이터가 없습니다.");
                return "error";
            }

            
            // ② 첫 번째 행만 예시로 PDF 생성
            ReportRecord2 record = records.get(0);

            logger.info("... record..."+ record.toString());
            
            // ③ 유효성 검사 실행
            csvValidator.validate(record);
            
            // ④ PDF 파일 생성 (PDF_SERVICE에서 좌표 JSON 매핑)
            String pdfPath = pdfService.createPdf(record, null);

            model.addAttribute("pdfPath", pdfPath);
            model.addAttribute("message", "PDF 생성 완료!");
            
            return "resultcsv"; // resultcsv.html에서 PDF 경로 표시
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("message", "PDF 생성 중 오류 발생: " + e.getMessage());
            return "error";
        }
    }
}
