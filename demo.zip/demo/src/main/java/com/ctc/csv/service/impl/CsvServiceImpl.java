package com.ctc.csv.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ctc.csv.ReportRecord2;
import com.ctc.csv.service.CsvService;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class CsvServiceImpl implements CsvService {
    private static final Logger logger = LoggerFactory.getLogger(CsvServiceImpl.class);
    
    /**
     * 중복 헤더를 지원하고, 쉼표(,)로 구분된 필드 내부의 다중값도 배열로 변환
     */
    public List<ReportRecord2> parseCsvWithDuplicateHeaders(MultipartFile csvFile) throws IOException {
        logger.info("... splitCsvLine ...");

        // ① CSV 헤더 분석 - "記事" 인덱스 목록 찾기
        List<Integer> memoIndexes = new ArrayList<>();
        String[] headers;

        try (BufferedReader br = new BufferedReader(new InputStreamReader(csvFile.getInputStream(), StandardCharsets.UTF_8))) {
            String headerLine = br.readLine();
            
            if (headerLine == null) {
                throw new IllegalArgumentException("CSV 파일에 헤더가 없습니다.");
            }
            
            headers = parseCsvLine(headerLine); // 안전한 CSV 라인 파서 사용
            
            for (int i = 0; i < headers.length; i++) {
                if (headers[i].trim().equals("記事")) {
                    memoIndexes.add(i);
                }
            }
            
            logger.info("記事 컬럼 인덱스: {}", memoIndexes);
        }
        
        // ② CsvMapper로 기본 매핑 수행
        List<ReportRecord2> records = new ArrayList<>();
        try (InputStream inputStream = csvFile.getInputStream()) {
            CsvMapper mapper = new CsvMapper();
            CsvSchema schema = CsvSchema.emptySchema().withHeader();

            MappingIterator<ReportRecord2> it = mapper
                    .readerFor(ReportRecord2.class)
                    .with(schema)
                    .readValues(inputStream);

            while (it.hasNext()) {
                records.add(it.next());
            }
        }
        
        logger.info("records: "+ records.toString());
        
        // ③ "記事" 중복열의 모든 값 읽어서 ReportRecord2.memo 배열에 다시 세팅
        if (!records.isEmpty()) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(csvFile.getInputStream(), StandardCharsets.UTF_8))) {
                br.readLine(); // 헤더 스킵
                String dataLine = br.readLine();
                
                if (dataLine != null) {
                    String[] cols = parseCsvLine(dataLine); // 안전하게 따옴표 감안 파싱
                    List<String> memoList = new ArrayList<>();

                    logger.info("cols: "+ Arrays.toString(cols));
                    
                    // "記事" 인덱스 순서에 맞게 값 추출
                    for (Integer idx : memoIndexes) {
                        if (idx < cols.length && !cols[idx].isBlank()) {
                            memoList.add(cols[idx].trim());
                        }
                    }

                    logger.info("記事 memoList: {}", memoList);
                    
                    ReportRecord2 record = records.get(0);
                    record.setMemo(String.join(",", memoList));
                    
                    logger.info("記事 배열 재정렬 완료: {}", Arrays.toString(record.memo));
                }
            }
        }

        logger.info("CSV 파싱 완료: {}건", records.size());
        logger.info("첫 번째 레코드: {}", records.get(0));
        
        return records;
    }
    
    /**
     * 따옴표가 포함된 CSV 한 줄을 안전하게 파싱
     * (예: "行事テスト1, 行事テスト2, 行事テスト3" → 하나의 필드로 처리)
     */
    private String[] parseCsvLine(String line) {
        List<String> tokens = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (c == '\"') {
                inQuotes = !inQuotes; // 따옴표 열림/닫힘 토글
            } else if (c == ',' && !inQuotes) {
                tokens.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(c);
            }
        }
        tokens.add(sb.toString());
        
        return tokens.toArray(new String[0]);
    }

}
