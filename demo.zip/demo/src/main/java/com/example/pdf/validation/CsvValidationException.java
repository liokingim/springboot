package com.example.pdf.validation;

public class CsvValidationException extends RuntimeException {
    public CsvValidationException(String message) {
        super(message);
    }
}