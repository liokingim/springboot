package com.example.pdf.validation;

import org.springframework.stereotype.Component;

import com.ctc.csv.ReportRecord2;

@Component
public class CsvValidator {

    public void validate(ReportRecord2 record) {

        // ① 필수 값 체크
        if (isBlank(record.getDate())) {
            throw new CsvValidationException("日付(날짜) 값이 없습니다.");
        }
        if (isBlank(record.getWeather())) {
            throw new CsvValidationException("天候(날씨) 값이 없습니다.");
        }

        // ② 날짜 형식 체크 (YYYY-MM-DD)
        if (!record.getDate().matches("\\d{4}-\\d{2}-\\d{2}")) {
            throw new CsvValidationException("日付 형식 오류: YYYY-MM-DD 형태여야 합니다.");
        }

        // ③ 기온 형식 체크 (예: 10.0℃〜20.0℃)
        if (!isBlank(record.getTemperature()) &&
            !record.getTemperature().matches(".*℃.*")) {
            throw new CsvValidationException("気温 형식 오류: 예) 10.0℃〜20.0℃");
        }

        // ④ 배열 필드 체크
        if (record.getEvent() == null || record.getEvent().length == 0) {
            throw new CsvValidationException("行事一覧(행사 목록)이 최소 1개 이상 필요합니다.");
        }

        // ⑤ 車号 배열 형식 체크
        for (String car : record.getCarNo()) {
            if (!car.matches("[0-9A-Z\\-]+")) {
                throw new CsvValidationException("車号 형식 오류: " + car);
            }
        }
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}